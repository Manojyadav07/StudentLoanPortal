![Architecture Diagram](architecture-diagram.png)
