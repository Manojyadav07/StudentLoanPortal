INSERT INTO student (name, dob, email, loan_amount)
VALUES ('Jane Doe', '2000-01-15', 'jane@example.com', 15000.00);
